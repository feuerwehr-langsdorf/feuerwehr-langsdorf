|[Home](index.md)|[Kontakte/Abteilungen](kontakte.md)|[Downloads](downloads.md)|[Impressum](impressum.md)|[Einsätze](https://feuerwehr.lich.de/einsaetze)|

# Kontakte

|[Einsatzabteilung](https://feuerwehr.lich.de/abteilungen/langsdorf)|Oliver Schauermann |Wehrführer |wehrfuehrung.langsdorf@feuerwehr.lich.de |0170/4599822|
||Stephan Roth |Stellvertretender Wehrführer |wehrfuehrung.langsdorf@feuerwehr.lich.de |0162-6890171|
|[Verein](https://kuczera.github.io/feuerwehr-langsdorf/)|Daniel Jung |1. Vorsitzender Verein |verein@feuerwehr-langsdorf.de|0172/6169024|
||Tobias Schäfer |2. Vorsitzender Verein |verein@feuerwehr-langsdorf.de|0170/3630568|
|[Jugendfeuerwehr](https://feuerwehr.lich.de/jf-langsdorf)|Max Mückstein |Jugendfeuerwehrwart |jugendfeuerwehr.langsdorf@feuerwehr.lich.de |0172/7815077 |
||Mika Bauer |Stellvertretender Jugendfeuerwehrwart |jugendfeuerwehr.langsdorf@feuerwehr.lich.de |0152/59023691|
|[Minifeuerwehr](https://feuerwehr.lich.de/mf-langsdorf)|Wolf-Christopher Gramatte |Minifeuerwehrwart |minifeuerwehr.langsdorf@feuerwehr.lich.de |0177/5999771|

