|[Home](index.md)|[Kontakte/Abteilungen](kontakte.md)|[Downloads](downloads.md)|[Impressum](impressum.md)|[Einsätze](https://feuerwehr.lich.de/einsaetze)|

# Impressum

## Freiwillige Feuerwehr Langsdorf e. V.
Schulschwan
35423 Lich-Langsdorf

E-Mail: verein@feuerwehr-langsdorf.de

Internet: www.feuerwehr-langsdorf.de

## Vertretungsberechtigter Vorstand:

Daniel Jung (1. Vorsitzender);  Brauhausgasse 9, 35423 Lich - Langsdorf)

Tobias Schäfer (2. Vorsitzender);  Lugge 2a, 35423 Lich - Langsdorf)

Registergericht: Amtsgericht Gießen
Registernummer: VR 2543

Haftungshinweis: Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.
